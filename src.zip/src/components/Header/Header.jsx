import React from 'react';
import { Layout, Menu, Button, Typography } from 'antd';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const { Header: AntHeader } = Layout;
const { Title } = Typography;

const Header = () => {
    const { isAuthenticated, logout } = useAuth();
    const location = useLocation();
    const navigate = useNavigate();

    // Si no está autenticado, no mostrar el menú
    if (!isAuthenticated) {
        return (
            <AntHeader style={{ background: '#fff', padding: '0 20px', boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
                <Title level={3} style={{ margin: '16px 0', display: 'inline-block' }}>STMG Admin</Title>
            </AntHeader>
        );
    }

    // Ítems del menú principal
    const menuItems = [
        {
            key: 'users',
            label: 'Usuarios',
            children: [
                { key: 'userList', label: <Link to="/users">Ver Usuarios</Link> },
                { key: 'userCreate', label: <Link to="/users/create">Crear Usuario</Link> }
            ]
        },
        {
            key: 'roles',
            label: 'Roles',
            children: [
                { key: 'roleList', label: <Link to="/roles">Ver Roles</Link> },
                { key: 'roleCreate', label: <Link to="/roles/create">Crear Rol</Link> }
            ]
        },
        {
            key: 'inventory',
            label: 'Inventario',
            children: [
                { key: 'inventoryList', label: <Link to="/inventory">Ver Inventario</Link> },
                { key: 'inventoryCreate', label: <Link to="/inventory/create">Agregar Item</Link> }
            ]
        }
    ];

    // Determinar la clave seleccionada basada en la ruta actual
    const getSelectedKey = () => {
        const path = location.pathname;
        if (path.includes('/users')) return 'users';
        if (path.includes('/roles')) return 'roles';
        if (path.includes('/inventory')) return 'inventory';
        return '';
    };

    // Manejar el cierre de sesión
    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    return (
        <AntHeader style={{ background: '#fff', padding: '0 20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
            <div style={{ display: 'flex', alignItems: 'center' }}>
                <Title level={3} style={{ margin: '16px 20px 16px 0', display: 'inline-block' }}>
                    <Link to="/" style={{ color: 'inherit' }}>STMG Admin</Link>
                </Title>
                <Menu
                    mode="horizontal"
                    selectedKeys={[getSelectedKey()]}
                    style={{ flex: 1, minWidth: 600 }}
                    items={menuItems}
                />
            </div>
            <Button type="primary" onClick={handleLogout}>
                Cerrar Sesión
            </Button>
        </AntHeader>
    );
};

export default Header;