import api from '../config/api';

const authService = {
    login: async (email, password) => {
        return await api.post('/auth/login', { email, password });
    },

    // Si necesitaras un endpoint de registro, podría ser así:
    // register: async (userData) => {
    //   return await api.post('/auth/register', userData);
    // },

    // Si necesitaras un endpoint para verificar el token, podría ser así:
    // verifyToken: async () => {
    //   return await api.get('/auth/verify');
    // },
};

export default authService;