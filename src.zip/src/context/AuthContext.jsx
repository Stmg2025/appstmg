import React, { createContext, useContext, useState, useEffect } from 'react';
import { message } from 'antd';
import authService from '../services/authService';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);
    const [isAuthenticated, setIsAuthenticated] = useState(false);

    useEffect(() => {
        const token = localStorage.getItem('token');
        if (token) {
            setIsAuthenticated(true);
            // Aquí podríamos verificar el token o cargar datos del usuario
            setLoading(false);
        } else {
            setIsAuthenticated(false);
            setLoading(false);
        }
    }, []);

    const login = async (email, password) => {
        try {
            setLoading(true);
            const response = await authService.login(email, password);
            if (response.data.success) {
                localStorage.setItem('token', response.data.token);
                setIsAuthenticated(true);
                message.success('Inicio de sesión exitoso');
                return true;
            }
        } catch (error) {
            console.error('Error al iniciar sesión:', error);
            message.error('Error al iniciar sesión. Verifica tus credenciales.');
            return false;
        } finally {
            setLoading(false);
        }
    };

    const logout = () => {
        localStorage.removeItem('token');
        setIsAuthenticated(false);
        setUser(null);
        message.success('Sesión cerrada correctamente');
    };

    const value = {
        user,
        loading,
        isAuthenticated,
        login,
        logout,
    };

    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export default AuthContext;