import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Card, Descriptions, Button, Spin, message, Typography, Tag } from 'antd';
import { EditOutlined, ArrowLeftOutlined, WarningOutlined } from '@ant-design/icons';
import inventoryService from '../../services/inventoryService';

const { Title } = Typography;

const InventoryView = () => {
    const { id } = useParams();
    const [item, setItem] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchItemData = async () => {
            try {
                setLoading(true);
                const response = await inventoryService.getInventoryItemById(id);

                if (response.data && response.data.success) {
                    setItem(response.data.item || response.data.inventory);
                } else {
                    message.error('Error al cargar los datos del item');
                }
            } catch (error) {
                console.error('Error al obtener item:', error);
                message.error('Error al cargar los datos del item');
            } finally {
                setLoading(false);
            }
        };

        fetchItemData();
    }, [id]);

    if (loading) {
        return <div style={{ textAlign: 'center', padding: '50px' }}><Spin size="large" /></div>;
    }

    if (!item) {
        return (
            <div>
                <Title level={3}>Item no encontrado</Title>
                <Link to="/inventory">
                    <Button type="primary">Volver al inventario</Button>
                </Link>
            </div>
        );
    }

    // Calcular el margen de ganancia
    const margin = item.valor - item.costo;
    const marginPercentage = ((margin / item.costo) * 100).toFixed(2);

    // Determinar el estado del stock
    const getStockStatus = (stock) => {
        if (stock <= 0) {
            return <Tag color="red">Sin Stock</Tag>;
        } else if (stock < 5) {
            return <Tag color="orange" icon={<WarningOutlined />}>Stock Bajo</Tag>;
        } else {
            return <Tag color="green">Disponible</Tag>;
        }
    };

    return (
        <div>
            <div style={{ marginBottom: 16, display: 'flex', justifyContent: 'space-between' }}>
                <Title level={2}>Detalle del Item</Title>
                <div>
                    <Link to="/inventory">
                        <Button icon={<ArrowLeftOutlined />} style={{ marginRight: 8 }}>
                            Volver
                        </Button>
                    </Link>
                    <Link to={`/inventory/edit/${id}`}>
                        <Button type="primary" icon={<EditOutlined />}>
                            Editar
                        </Button>
                    </Link>
                </div>
            </div>

            <Card>
                <Descriptions bordered column={1}>
                    <Descriptions.Item label="ID">{item.id}</Descriptions.Item>
                    <Descriptions.Item label="Código">{item.codigo}</Descriptions.Item>
                    <Descriptions.Item label="Descripción">{item.descripcion}</Descriptions.Item>
                    <Descriptions.Item label="Ubicación">{item.ubicacion}</Descriptions.Item>
                    <Descriptions.Item label="Valor (Precio de Venta)">${item.valor?.toLocaleString() || 0}</Descriptions.Item>
                    <Descriptions.Item label="Costo (Precio de Compra)">${item.costo?.toLocaleString() || 0}</Descriptions.Item>
                    <Descriptions.Item label="Margen">${margin?.toLocaleString() || 0} ({marginPercentage}%)</Descriptions.Item>
                    <Descriptions.Item label="Stock">
                        {item.stock} {getStockStatus(item.stock)}
                    </Descriptions.Item>
                </Descriptions>
            </Card>
        </div>
    );
};

export default InventoryView;