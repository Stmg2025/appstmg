import React, { useState, useEffect } from 'react';
import { Form, Input, Button, InputNumber, Typography, message, Spin, Card } from 'antd';
import { useParams, useNavigate } from 'react-router-dom';
import inventoryService from '../../services/inventoryService';

const { Title } = Typography;

const InventoryEdit = () => {
    const { id } = useParams();
    const [form] = Form.useForm();
    const [loading, setLoading] = useState(false);
    const [initialLoading, setInitialLoading] = useState(true);
    const navigate = useNavigate();

    // Cargar datos del ítem
    useEffect(() => {
        const fetchItemData = async () => {
            try {
                setInitialLoading(true);
                console.log('Fetching inventory item data for ID:', id);
                const response = await inventoryService.getInventoryItemById(id);

                if (response.data && response.data.success) {
                    // Determinar si los datos vienen en item o inventory
                    const itemData = response.data.item || response.data.inventory;

                    if (itemData) {
                        // Formatear los datos para el formulario
                        const formData = {
                            codigo: itemData.codigo || '',
                            descripcion: itemData.descripcion || '',
                            ubicacion: itemData.ubicacion || '',
                            valor: parseFloat(itemData.valor) || 0,
                            costo: parseFloat(itemData.costo) || 0,
                            stock: parseInt(itemData.stock, 10) || 0
                        };

                        // Establecer los datos en el formulario
                        form.setFieldsValue(formData);
                        message.success('Datos cargados correctamente');
                    } else {
                        message.warning('No se pudieron cargar los datos automáticamente. Usa "Cargar Datos Demo" o ingresa la información manualmente.');
                    }
                } else {
                    message.warning('No se pudieron cargar los datos automáticamente. Usa "Cargar Datos Demo" o ingresa la información manualmente.');
                }
            } catch (error) {
                console.error('Error al cargar datos:', error);
                message.warning('No se pudieron cargar los datos automáticamente. Usa "Cargar Datos Demo" o ingresa la información manualmente.');
            } finally {
                setInitialLoading(false);
            }
        };

        fetchItemData();
    }, [id, form]);

    const onFinish = async (values) => {
        try {
            setLoading(true);
            const response = await inventoryService.updateInventoryItem(id, values);

            if (response.data && response.data.success) {
                message.success('Ítem actualizado exitosamente');
                navigate(`/inventory/${id}`);
            } else {
                message.error('Error al actualizar el ítem');
            }
        } catch (error) {
            console.error('Error al actualizar ítem:', error);
            message.error('Error al actualizar el ítem');
        } finally {
            setLoading(false);
        }
    };

    const handleDemoData = () => {
        // Cargar datos de demostración basados en el ID
        const demoValues = {
            codigo: 'RP00' + id,
            descripcion: 'Sensor de temperatura avanzado',
            ubicacion: 'Bodega Principal, Estante B-42',
            valor: 75000,
            costo: 45000,
            stock: 8
        };
        form.setFieldsValue(demoValues);
        message.success('Datos demo cargados correctamente');
    };

    if (initialLoading) {
        return <div style={{ textAlign: 'center', padding: '50px' }}><Spin size="large" /></div>;
    }

    return (
        <div>
            <Title level={2}>Editar Ítem de Inventario</Title>

            <Card style={{ marginBottom: 16 }}>
                <Form
                    form={form}
                    layout="vertical"
                    onFinish={onFinish}
                    style={{ maxWidth: 600 }}
                >
                    <Form.Item
                        name="codigo"
                        label="Código"
                        rules={[{ required: true, message: 'Por favor ingresa el código del ítem' }]}
                    >
                        <Input placeholder="Ej: RP001" />
                    </Form.Item>

                    <Form.Item
                        name="descripcion"
                        label="Descripción"
                        rules={[{ required: true, message: 'Por favor ingresa una descripción' }]}
                    >
                        <Input.TextArea
                            placeholder="Descripción detallada del ítem"
                            rows={3}
                        />
                    </Form.Item>

                    <Form.Item
                        name="ubicacion"
                        label="Ubicación"
                        rules={[{ required: true, message: 'Por favor ingresa la ubicación del ítem' }]}
                    >
                        <Input placeholder="Ej: Bodega 1, Estante A-12" />
                    </Form.Item>

                    <Form.Item
                        name="valor"
                        label="Valor (Precio de Venta)"
                        rules={[{ required: true, message: 'Por favor ingresa el valor del ítem' }]}
                    >
                        <InputNumber
                            style={{ width: '100%' }}
                            formatter={value => `$ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                            parser={value => value.replace(/\$\s?|(,*)/g, '')}
                            min={0}
                            placeholder="Valor en pesos"
                        />
                    </Form.Item>

                    <Form.Item
                        name="costo"
                        label="Costo (Precio de Compra)"
                        rules={[{ required: true, message: 'Por favor ingresa el costo del ítem' }]}
                    >
                        <InputNumber
                            style={{ width: '100%' }}
                            formatter={value => `$ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                            parser={value => value.replace(/\$\s?|(,*)/g, '')}
                            min={0}
                            placeholder="Costo en pesos"
                        />
                    </Form.Item>

                    <Form.Item
                        name="stock"
                        label="Stock"
                        rules={[{ required: true, message: 'Por favor ingresa el stock' }]}
                    >
                        <InputNumber
                            style={{ width: '100%' }}
                            min={0}
                            placeholder="Cantidad disponible"
                        />
                    </Form.Item>

                    <Form.Item>
                        <Button type="primary" htmlType="submit" loading={loading}>
                            Actualizar Ítem
                        </Button>
                        <Button
                            style={{ marginLeft: 8 }}
                            onClick={() => navigate(`/inventory/${id}`)}
                        >
                            Cancelar
                        </Button>
                        <Button
                            style={{ marginLeft: 8 }}
                            type="dashed"
                            onClick={handleDemoData}
                        >
                            Cargar Datos Demo
                        </Button>
                    </Form.Item>
                </Form>
            </Card>
        </div>
    );
};

export default InventoryEdit;